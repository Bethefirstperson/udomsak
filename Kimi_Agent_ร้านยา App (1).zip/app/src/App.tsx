import { AppProvider, useApp } from '@/context/AppContext';
import { Sidebar } from '@/components/Sidebar';
import { Toast } from '@/components/Toast';
import { Dashboard } from '@/sections/Dashboard';
import { CreateBill } from '@/sections/CreateBill';
import { Bills } from '@/sections/Bills';
import { Medicines } from '@/sections/Medicines';
import { Customers } from '@/sections/Customers';
import { Reports } from '@/sections/Reports';
import { Settings } from '@/sections/Settings';

function MainContent() {
  const { currentView } = useApp();

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'create-bill':
        return <CreateBill />;
      case 'bills':
        return <Bills />;
      case 'medicines':
        return <Medicines />;
      case 'customers':
        return <Customers />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F7]">
      <Sidebar />
      <main className="ml-64 min-h-screen">
        <div className="p-6 max-w-[1400px] mx-auto">
          {renderView()}
        </div>
      </main>
      <Toast />
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}

export default App;
