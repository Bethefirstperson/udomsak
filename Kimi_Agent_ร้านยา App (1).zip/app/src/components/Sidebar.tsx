import { 
  LayoutDashboard, 
  Receipt, 
  FileText, 
  Pill, 
  Users, 
  BarChart3, 
  Settings,
} from 'lucide-react';
import type { ViewType } from '@/types';
import { useApp } from '@/context/AppContext';
import { cn } from '@/lib/utils';

interface NavItem {
  id: ViewType;
  label: string;
  icon: React.ElementType;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'แดชบอร์ด', icon: LayoutDashboard },
  { id: 'create-bill', label: 'สร้างบิล', icon: Receipt },
  { id: 'bills', label: 'รายการบิล', icon: FileText },
  { id: 'medicines', label: 'คลังยา', icon: Pill },
  { id: 'customers', label: 'ลูกค้า', icon: Users },
  { id: 'reports', label: 'รายงาน', icon: BarChart3 },
  { id: 'settings', label: 'ตั้งค่า', icon: Settings },
];

export function Sidebar() {
  const { currentView, setCurrentView } = useApp();

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-[#F5F5F7] border-r border-[#E5E5E7] z-50 flex flex-col">
      {/* Logo */}
      <div className="p-6">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#007AFF] flex items-center justify-center">
            <Pill className="w-4 h-4 text-white" strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-[#1D1D1F] tracking-tight">PharmaFlow</h1>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 space-y-0.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                isActive
                  ? "bg-white text-[#007AFF] shadow-apple"
                  : "text-[#6E6E73] hover:text-[#1D1D1F] hover:bg-white/50"
              )}
            >
              <Icon 
                className={cn(
                  "w-[18px] h-[18px] transition-transform duration-200",
                  isActive && "stroke-[2.5]"
                )} 
              />
              <span className="flex-1 text-left text-sm font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* User Profile */}
      <div className="p-3">
        <div className="flex items-center gap-3 p-3 rounded-xl bg-white shadow-apple">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#007AFF] to-[#5856D6] flex items-center justify-center">
            <span className="text-xs font-semibold text-white">PH</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-[#1D1D1F] truncate">เภสัชกร</p>
            <p className="text-xs text-[#8E8E93] truncate">pharmacist@pharmaflow.com</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
