import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  color: 'blue' | 'green' | 'orange' | 'red' | 'purple' | 'gray';
  change?: number;
  changeLabel?: string;
}

const colorMap = {
  blue: { bg: 'bg-[#007AFF]/8', text: 'text-[#007AFF]', icon: 'text-[#007AFF]' },
  green: { bg: 'bg-[#34C759]/8', text: 'text-[#34C759]', icon: 'text-[#34C759]' },
  orange: { bg: 'bg-[#FF9500]/8', text: 'text-[#FF9500]', icon: 'text-[#FF9500]' },
  red: { bg: 'bg-[#FF3B30]/8', text: 'text-[#FF3B30]', icon: 'text-[#FF3B30]' },
  purple: { bg: 'bg-[#AF52DE]/8', text: 'text-[#AF52DE]', icon: 'text-[#AF52DE]' },
  gray: { bg: 'bg-[#8E8E93]/8', text: 'text-[#8E8E93]', icon: 'text-[#8E8E93]' },
};

export function StatCard({
  title,
  value,
  icon: Icon,
  color,
  change,
  changeLabel,
}: StatCardProps) {
  const colors = colorMap[color];
  const isPositive = change && change >= 0;

  return (
    <div className="bg-white rounded-2xl p-5 shadow-apple hover:shadow-apple-hover transition-all duration-300">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-xs font-medium text-[#8E8E93] uppercase tracking-wide mb-1">{title}</p>
          <h3 className="text-2xl font-semibold text-[#1D1D1F] tracking-tight">{value}</h3>
          
          {change !== undefined && (
            <div className="flex items-center gap-1.5 mt-2">
              <span className={cn(
                "text-xs font-medium",
                isPositive ? "text-[#34C759]" : "text-[#FF3B30]"
              )}>
                {isPositive ? '+' : ''}{change}%
              </span>
              {changeLabel && (
                <span className="text-xs text-[#8E8E93]">{changeLabel}</span>
              )}
            </div>
          )}
        </div>
        
        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", colors.bg)}>
          <Icon className={cn("w-5 h-5", colors.icon)} strokeWidth={2} />
        </div>
      </div>
    </div>
  );
}
