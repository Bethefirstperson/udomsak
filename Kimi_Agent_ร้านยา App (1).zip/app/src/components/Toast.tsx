import { CheckCircle, XCircle, AlertCircle, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { cn } from '@/lib/utils';

export function Toast() {
  const { toast, hideToast } = useApp();

  if (!toast) return null;

  const icons = {
    success: CheckCircle,
    error: XCircle,
    info: AlertCircle,
  };

  const styles = {
    success: 'bg-[#34C759]',
    error: 'bg-[#FF3B30]',
    info: 'bg-[#007AFF]',
  };

  const Icon = icons[toast.type];

  return (
    <div className="fixed top-4 right-4 z-[100] animate-slide-in-right">
      <div className={cn(
        "flex items-center gap-3 px-4 py-3 rounded-xl text-white shadow-apple-lg min-w-[280px]",
        styles[toast.type]
      )}>
        <Icon className="w-5 h-5 flex-shrink-0" strokeWidth={2} />
        <p className="flex-1 text-sm font-medium">{toast.message}</p>
        <button
          onClick={hideToast}
          className="p-1 hover:bg-white/20 rounded-lg transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
