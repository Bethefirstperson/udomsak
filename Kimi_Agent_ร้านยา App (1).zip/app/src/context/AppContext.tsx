import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { Bill, Medicine, Customer, CartItem, ViewType, Stats } from '@/types';
import { mockBills, mockMedicines, mockCustomers } from '@/data/mockData';

interface AppContextType {
  // Data
  bills: Bill[];
  medicines: Medicine[];
  customers: Customer[];
  cart: CartItem[];
  
  // Navigation
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  
  // Cart operations
  addToCart: (medicine: Medicine) => void;
  removeFromCart: (medicineId: string) => void;
  updateCartQuantity: (medicineId: string, quantity: number) => void;
  clearCart: () => void;
  
  // Bill operations
  createBill: (customerName: string, customerPhone: string) => Bill;
  deleteBill: (billId: string) => void;
  updateBillStatus: (billId: string, status: 'paid' | 'pending' | 'cancelled') => void;
  
  // Medicine operations
  addMedicine: (medicine: Omit<Medicine, 'id'>) => void;
  updateMedicine: (medicine: Medicine) => void;
  deleteMedicine: (medicineId: string) => void;
  updateStock: (medicineId: string, newStock: number) => void;
  
  // Customer operations
  addCustomer: (customer: Omit<Customer, 'id' | 'totalVisits' | 'totalSpent' | 'lastVisit'>) => void;
  updateCustomer: (customer: Customer) => void;
  deleteCustomer: (customerId: string) => void;
  
  // Stats
  stats: Stats;
  
  // Search
  searchMedicines: (query: string) => Medicine[];
  searchBills: (query: string) => Bill[];
  searchCustomers: (query: string) => Customer[];
  
  // Toast
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type: 'success' | 'error' | 'info') => void;
  hideToast: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  // Data states
  const [bills, setBills] = useState<Bill[]>(() => {
    const saved = localStorage.getItem('pharmaflow_bills');
    return saved ? JSON.parse(saved) : mockBills;
  });
  
  const [medicines, setMedicines] = useState<Medicine[]>(() => {
    const saved = localStorage.getItem('pharmaflow_medicines');
    return saved ? JSON.parse(saved) : mockMedicines;
  });
  
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem('pharmaflow_customers');
    return saved ? JSON.parse(saved) : mockCustomers;
  });
  
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Persist data to localStorage
  useEffect(() => {
    localStorage.setItem('pharmaflow_bills', JSON.stringify(bills));
  }, [bills]);

  useEffect(() => {
    localStorage.setItem('pharmaflow_medicines', JSON.stringify(medicines));
  }, [medicines]);

  useEffect(() => {
    localStorage.setItem('pharmaflow_customers', JSON.stringify(customers));
  }, [customers]);

  // Toast timer
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Calculate stats
  const stats: Stats = {
    totalSalesToday: bills
      .filter(b => {
        const billDate = new Date(b.createdAt).toDateString();
        const today = new Date().toDateString();
        return billDate === today && b.status === 'paid';
      })
      .reduce((sum, b) => sum + b.total, 0),
    totalBillsToday: bills.filter(b => {
      const billDate = new Date(b.createdAt).toDateString();
      const today = new Date().toDateString();
      return billDate === today;
    }).length,
    totalMedicines: medicines.length,
    lowStockItems: medicines.filter(m => m.stock <= 10).length,
  };

  // Cart operations
  const addToCart = (medicine: Medicine) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === medicine.id);
      if (existing) {
        if (existing.quantity >= medicine.stock) {
          showToast('สินค้าในสต็อกไม่เพียงพอ', 'error');
          return prev;
        }
        return prev.map(item =>
          item.id === medicine.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...medicine, quantity: 1 }];
    });
  };

  const removeFromCart = (medicineId: string) => {
    setCart(prev => prev.filter(item => item.id !== medicineId));
  };

  const updateCartQuantity = (medicineId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(medicineId);
      return;
    }
    const medicine = medicines.find(m => m.id === medicineId);
    if (medicine && quantity > medicine.stock) {
      showToast('สินค้าในสต็อกไม่เพียงพอ', 'error');
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.id === medicineId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  // Bill operations
  const createBill = (customerName: string, customerPhone: string): Bill => {
    const now = new Date();
    const billNumber = `BILL-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${String(bills.length + 1).padStart(3, '0')}`;
    
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const tax = subtotal * 0.07;
    const total = subtotal + tax;

    const newBill: Bill = {
      id: Date.now().toString(),
      billNumber,
      customerName,
      customerPhone,
      items: cart.map(item => ({
        medicineId: item.id,
        medicineName: item.name,
        quantity: item.quantity,
        unitPrice: item.price,
        total: item.price * item.quantity,
      })),
      subtotal,
      tax,
      total,
      status: 'paid',
      createdAt: now.toISOString(),
    };

    setBills(prev => [newBill, ...prev]);

    // Update stock
    cart.forEach(item => {
      updateStock(item.id, item.stock - item.quantity);
    });

    // Update or create customer
    const existingCustomer = customers.find(c => c.phone === customerPhone);
    if (existingCustomer) {
      setCustomers(prev =>
        prev.map(c =>
          c.phone === customerPhone
            ? { ...c, totalVisits: c.totalVisits + 1, totalSpent: c.totalSpent + total, lastVisit: now.toISOString() }
            : c
        )
      );
    } else if (customerName && customerPhone) {
      const newCustomer: Customer = {
        id: Date.now().toString(),
        name: customerName,
        phone: customerPhone,
        totalVisits: 1,
        totalSpent: total,
        lastVisit: now.toISOString(),
      };
      setCustomers(prev => [...prev, newCustomer]);
    }

    clearCart();
    showToast('สร้างบิลสำเร็จ', 'success');
    return newBill;
  };

  const deleteBill = (billId: string) => {
    setBills(prev => prev.filter(b => b.id !== billId));
    showToast('ลบบิลสำเร็จ', 'success');
  };

  const updateBillStatus = (billId: string, status: 'paid' | 'pending' | 'cancelled') => {
    setBills(prev =>
      prev.map(b => (b.id === billId ? { ...b, status } : b))
    );
    showToast('อัปเดตสถานะสำเร็จ', 'success');
  };

  // Medicine operations
  const addMedicine = (medicine: Omit<Medicine, 'id'>) => {
    const newMedicine: Medicine = {
      ...medicine,
      id: Date.now().toString(),
    };
    setMedicines(prev => [...prev, newMedicine]);
    showToast('เพิ่มยาสำเร็จ', 'success');
  };

  const updateMedicine = (medicine: Medicine) => {
    setMedicines(prev =>
      prev.map(m => (m.id === medicine.id ? medicine : m))
    );
    showToast('อัปเดตข้อมูลยาสำเร็จ', 'success');
  };

  const deleteMedicine = (medicineId: string) => {
    setMedicines(prev => prev.filter(m => m.id !== medicineId));
    showToast('ลบยาสำเร็จ', 'success');
  };

  const updateStock = (medicineId: string, newStock: number) => {
    setMedicines(prev =>
      prev.map(m => (m.id === medicineId ? { ...m, stock: newStock } : m))
    );
  };

  // Customer operations
  const addCustomer = (customer: Omit<Customer, 'id' | 'totalVisits' | 'totalSpent' | 'lastVisit'>) => {
    const newCustomer: Customer = {
      ...customer,
      id: Date.now().toString(),
      totalVisits: 0,
      totalSpent: 0,
      lastVisit: '',
    };
    setCustomers(prev => [...prev, newCustomer]);
    showToast('เพิ่มลูกค้าสำเร็จ', 'success');
  };

  const updateCustomer = (customer: Customer) => {
    setCustomers(prev =>
      prev.map(c => (c.id === customer.id ? customer : c))
    );
    showToast('อัปเดตข้อมูลลูกค้าสำเร็จ', 'success');
  };

  const deleteCustomer = (customerId: string) => {
    setCustomers(prev => prev.filter(c => c.id !== customerId));
    showToast('ลบลูกค้าสำเร็จ', 'success');
  };

  // Search functions
  const searchMedicines = (query: string) => {
    const lowerQuery = query.toLowerCase();
    return medicines.filter(
      m =>
        m.name.toLowerCase().includes(lowerQuery) ||
        m.category.toLowerCase().includes(lowerQuery)
    );
  };

  const searchBills = (query: string) => {
    const lowerQuery = query.toLowerCase();
    return bills.filter(
      b =>
        b.billNumber.toLowerCase().includes(lowerQuery) ||
        b.customerName.toLowerCase().includes(lowerQuery) ||
        b.customerPhone.includes(query)
    );
  };

  const searchCustomers = (query: string) => {
    const lowerQuery = query.toLowerCase();
    return customers.filter(
      c =>
        c.name.toLowerCase().includes(lowerQuery) ||
        c.phone.includes(query)
    );
  };

  // Toast
  const showToast = (message: string, type: 'success' | 'error' | 'info') => {
    setToast({ message, type });
  };

  const hideToast = () => {
    setToast(null);
  };

  return (
    <AppContext.Provider
      value={{
        bills,
        medicines,
        customers,
        cart,
        currentView,
        setCurrentView,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        createBill,
        deleteBill,
        updateBillStatus,
        addMedicine,
        updateMedicine,
        deleteMedicine,
        updateStock,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        stats,
        searchMedicines,
        searchBills,
        searchCustomers,
        toast,
        showToast,
        hideToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
