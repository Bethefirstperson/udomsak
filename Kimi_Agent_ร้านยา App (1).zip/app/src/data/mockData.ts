import type { Bill, Medicine, Customer } from '@/types';

export const mockMedicines: Medicine[] = [
  { id: '1', name: 'Paracetamol 500mg', category: 'Pain Relief', description: 'For fever and mild to moderate pain', price: 35, stock: 150 },
  { id: '2', name: 'Ibuprofen 400mg', category: 'Pain Relief', description: 'Anti-inflammatory pain reliever', price: 45, stock: 120 },
  { id: '3', name: 'Amoxicillin 500mg', category: 'Antibiotics', description: 'Broad-spectrum antibiotic', price: 120, stock: 80 },
  { id: '4', name: 'Cetirizine 10mg', category: 'Allergy', description: 'Antihistamine for allergies', price: 55, stock: 200 },
  { id: '5', name: 'Omeprazole 20mg', category: 'Digestive', description: 'For acid reflux and heartburn', price: 85, stock: 95 },
  { id: '6', name: 'Vitamin C 1000mg', category: 'Vitamins', description: 'Immune system support', price: 180, stock: 60 },
  { id: '7', name: 'Multivitamin', category: 'Vitamins', description: 'Daily multivitamin supplement', price: 250, stock: 45 },
  { id: '8', name: 'Aspirin 81mg', category: 'Pain Relief', description: 'Low dose aspirin', price: 40, stock: 110 },
  { id: '9', name: 'Loratadine 10mg', category: 'Allergy', description: 'Non-drowsy antihistamine', price: 65, stock: 75 },
  { id: '10', name: 'Metformin 500mg', category: 'Diabetes', description: 'For type 2 diabetes', price: 95, stock: 8 },
  { id: '11', name: 'Amlodipine 5mg', category: 'Heart', description: 'For high blood pressure', price: 110, stock: 5 },
  { id: '12', name: 'Simvastatin 20mg', category: 'Heart', description: 'For cholesterol management', price: 135, stock: 70 },
];

export const mockCustomers: Customer[] = [
  { id: '1', name: 'สมชาย ใจดี', phone: '081-234-5678', totalVisits: 15, totalSpent: 8750, lastVisit: '2026-01-30' },
  { id: '2', name: 'มานี รักษ์สุข', phone: '082-345-6789', totalVisits: 8, totalSpent: 4200, lastVisit: '2026-01-28' },
  { id: '3', name: 'ประเสริฐ สุขสบาย', phone: '083-456-7890', totalVisits: 22, totalSpent: 15600, lastVisit: '2026-01-29' },
  { id: '4', name: 'วิไลพร สุขใจ', phone: '084-567-8901', totalVisits: 5, totalSpent: 1850, lastVisit: '2026-01-25' },
  { id: '5', name: 'ธนากร มั่งคั่ง', phone: '085-678-9012', totalVisits: 12, totalSpent: 6800, lastVisit: '2026-01-27' },
];

export const mockBills: Bill[] = [
  {
    id: '1',
    billNumber: 'BILL-20260131-001',
    customerName: 'สมชาย ใจดี',
    customerPhone: '081-234-5678',
    items: [
      { medicineId: '1', medicineName: 'Paracetamol 500mg', quantity: 2, unitPrice: 35, total: 70 },
      { medicineId: '4', medicineName: 'Cetirizine 10mg', quantity: 1, unitPrice: 55, total: 55 },
    ],
    subtotal: 125,
    tax: 8.75,
    total: 133.75,
    status: 'paid',
    createdAt: '2026-01-31T09:30:00',
  },
  {
    id: '2',
    billNumber: 'BILL-20260131-002',
    customerName: 'มานี รักษ์สุข',
    customerPhone: '082-345-6789',
    items: [
      { medicineId: '3', medicineName: 'Amoxicillin 500mg', quantity: 1, unitPrice: 120, total: 120 },
      { medicineId: '5', medicineName: 'Omeprazole 20mg', quantity: 1, unitPrice: 85, total: 85 },
    ],
    subtotal: 205,
    tax: 14.35,
    total: 219.35,
    status: 'paid',
    createdAt: '2026-01-31T10:15:00',
  },
  {
    id: '3',
    billNumber: 'BILL-20260131-003',
    customerName: 'ประเสริฐ สุขสบาย',
    customerPhone: '083-456-7890',
    items: [
      { medicineId: '6', medicineName: 'Vitamin C 1000mg', quantity: 2, unitPrice: 180, total: 360 },
      { medicineId: '7', medicineName: 'Multivitamin', quantity: 1, unitPrice: 250, total: 250 },
    ],
    subtotal: 610,
    tax: 42.70,
    total: 652.70,
    status: 'pending',
    createdAt: '2026-01-31T11:00:00',
  },
  {
    id: '4',
    billNumber: 'BILL-20260130-001',
    customerName: 'วิไลพร สุขใจ',
    customerPhone: '084-567-8901',
    items: [
      { medicineId: '2', medicineName: 'Ibuprofen 400mg', quantity: 1, unitPrice: 45, total: 45 },
    ],
    subtotal: 45,
    tax: 3.15,
    total: 48.15,
    status: 'paid',
    createdAt: '2026-01-30T14:20:00',
  },
  {
    id: '5',
    billNumber: 'BILL-20260130-002',
    customerName: 'ธนากร มั่งคั่ง',
    customerPhone: '085-678-9012',
    items: [
      { medicineId: '8', medicineName: 'Aspirin 81mg', quantity: 3, unitPrice: 40, total: 120 },
      { medicineId: '9', medicineName: 'Loratadine 10mg', quantity: 1, unitPrice: 65, total: 65 },
    ],
    subtotal: 185,
    tax: 12.95,
    total: 197.95,
    status: 'paid',
    createdAt: '2026-01-30T16:45:00',
  },
];

export const categories = [
  'All',
  'Pain Relief',
  'Antibiotics',
  'Allergy',
  'Digestive',
  'Vitamins',
  'Diabetes',
  'Heart',
];
