import { useState } from 'react';
import { 
  Search, 
  FileText, 
  Printer, 
  Trash2, 
  Eye,
  ChevronLeft,
  ChevronRight,
  Download,
  X
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { Bill } from '@/types';
import { format } from '@/lib/utils';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const ITEMS_PER_PAGE = 10;

const statusConfig = {
  paid: { label: 'ชำระแล้ว', color: 'bg-[#34C759]/10 text-[#34C759]' },
  pending: { label: 'รอชำระ', color: 'bg-[#FF9500]/10 text-[#FF9500]' },
  cancelled: { label: 'ยกเลิก', color: 'bg-[#FF3B30]/10 text-[#FF3B30]' },
};

export function Bills() {
  const { bills, deleteBill, updateBillStatus, searchBills } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'paid' | 'pending' | 'cancelled'>('all');

  const filteredBills = bills.filter(bill => {
    const matchesSearch = searchBills(searchQuery).includes(bill);
    const matchesStatus = filterStatus === 'all' || bill.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const totalPages = Math.ceil(filteredBills.length / ITEMS_PER_PAGE);
  const paginatedBills = filteredBills.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handlePrint = (bill: Bill) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>บิล ${bill.billNumber}</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
              body { font-family: 'Inter', sans-serif; padding: 40px; max-width: 400px; margin: 0 auto; color: #1D1D1F; }
              .header { text-align: center; margin-bottom: 30px; }
              .header h1 { margin: 0; font-size: 22px; font-weight: 600; }
              .header p { margin: 4px 0; color: #8E8E93; font-size: 13px; }
              .info { margin-bottom: 20px; }
              .info-row { display: flex; justify-content: space-between; margin: 6px 0; font-size: 13px; }
              .items { width: 100%; border-collapse: collapse; margin: 20px 0; }
              .items th, .items td { text-align: left; padding: 8px; font-size: 13px; border-bottom: 1px solid #E5E5E7; }
              .items th { color: #8E8E93; font-weight: 500; }
              .total { margin-top: 20px; border-top: 2px solid #1D1D1F; padding-top: 15px; }
              .total-row { display: flex; justify-content: space-between; margin: 6px 0; font-size: 13px; }
              .total-row.grand { font-size: 16px; font-weight: 600; color: #007AFF; margin-top: 10px; }
              .footer { text-align: center; margin-top: 40px; color: #8E8E93; font-size: 11px; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>PharmaFlow</h1>
              <p>ร้านขายยา</p>
              <p>โทร: 02-123-4567</p>
            </div>
            <div class="info">
              <div class="info-row">
                <span>เลขที่บิล:</span>
                <span>${bill.billNumber}</span>
              </div>
              <div class="info-row">
                <span>วันที่:</span>
                <span>${format.dateTime(bill.createdAt)}</span>
              </div>
              <div class="info-row">
                <span>ลูกค้า:</span>
                <span>${bill.customerName || 'ลูกค้าทั่วไป'}</span>
              </div>
              <div class="info-row">
                <span>เบอร์โทร:</span>
                <span>${bill.customerPhone || '-'}</span>
              </div>
            </div>
            <table class="items">
              <thead>
                <tr>
                  <th>รายการ</th>
                  <th style="text-align: center;">จำนวน</th>
                  <th style="text-align: right;">ราคา</th>
                </tr>
              </thead>
              <tbody>
                ${bill.items.map(item => `
                  <tr>
                    <td>${item.medicineName}</td>
                    <td style="text-align: center;">${item.quantity}</td>
                    <td style="text-align: right;">${format.currency(item.total)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            <div class="total">
              <div class="total-row">
                <span>ยอดรวม:</span>
                <span>${format.currency(bill.subtotal)}</span>
              </div>
              <div class="total-row">
                <span>ภาษี (7%):</span>
                <span>${format.currency(bill.tax)}</span>
              </div>
              <div class="total-row grand">
                <span>ยอดสุทธิ:</span>
                <span>${format.currency(bill.total)}</span>
              </div>
            </div>
            <div class="footer">
              <p>ขอบคุณที่ใช้บริการ</p>
              <p>PharmaFlow - ร้านขายยา</p>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleExportCSV = () => {
    const headers = ['เลขที่บิล', 'ลูกค้า', 'เบอร์โทร', 'วันที่', 'จำนวนรายการ', 'ยอดรวม', 'สถานะ'];
    const rows = filteredBills.map(bill => [
      bill.billNumber,
      bill.customerName || 'ลูกค้าทั่วไป',
      bill.customerPhone || '-',
      format.dateTime(bill.createdAt),
      bill.items.length,
      bill.total,
      statusConfig[bill.status].label,
    ]);
    
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `bills-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-[#1D1D1F] tracking-tight">รายการบิล</h1>
          <p className="text-sm text-[#8E8E93] mt-0.5">จัดการและติดตามรายการบิลทั้งหมด</p>
        </div>
        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-3 py-2 bg-white rounded-xl shadow-apple hover:shadow-apple-hover transition-all text-sm font-medium text-[#1D1D1F]"
        >
          <Download className="w-4 h-4" />
          ส่งออก CSV
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E8E93]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="ค้นหาบิลหรือลูกค้า..."
            className="w-full pl-9 pr-4 py-2.5 bg-white border-0 rounded-xl shadow-apple text-sm text-[#1D1D1F] placeholder:text-[#8E8E93] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
          />
        </div>
        <div className="flex gap-1.5 bg-white p-1 rounded-xl shadow-apple">
          {(['all', 'paid', 'pending', 'cancelled'] as const).map((status) => (
            <button
              key={status}
              onClick={() => {
                setFilterStatus(status);
                setCurrentPage(1);
              }}
              className={cn(
                "px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
                filterStatus === status
                  ? "bg-[#007AFF] text-white"
                  : "text-[#8E8E93] hover:text-[#1D1D1F] hover:bg-[#F5F5F7]"
              )}
            >
              {status === 'all' && 'ทั้งหมด'}
              {status === 'paid' && 'ชำระแล้ว'}
              {status === 'pending' && 'รอชำระ'}
              {status === 'cancelled' && 'ยกเลิก'}
            </button>
          ))}
        </div>
      </div>

      {/* Bills Table */}
      <div className="bg-white rounded-2xl shadow-apple overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#F5F5F7]">
              <tr>
                <th className="px-4 py-3 text-left text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  เลขที่บิล
                </th>
                <th className="px-4 py-3 text-left text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  ลูกค้า
                </th>
                <th className="px-4 py-3 text-left text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  วันที่
                </th>
                <th className="px-4 py-3 text-center text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  รายการ
                </th>
                <th className="px-4 py-3 text-right text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  ยอดรวม
                </th>
                <th className="px-4 py-3 text-center text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  สถานะ
                </th>
                <th className="px-4 py-3 text-center text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  จัดการ
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E5E7]">
              {paginatedBills.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center">
                    <FileText className="w-10 h-10 mx-auto mb-2 text-[#E5E5E7]" />
                    <p className="text-sm text-[#8E8E93]">ไม่พบรายการบิล</p>
                  </td>
                </tr>
              ) : (
                paginatedBills.map((bill) => (
                  <tr key={bill.id} className="hover:bg-[#F5F5F7] transition-colors">
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-[#1D1D1F]">{bill.billNumber}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm text-[#1D1D1F]">
                        {bill.customerName || 'ลูกค้าทั่วไป'}
                      </p>
                      {bill.customerPhone && (
                        <p className="text-xs text-[#8E8E93]">{bill.customerPhone}</p>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm text-[#1D1D1F]">{format.date(bill.createdAt)}</p>
                      <p className="text-xs text-[#8E8E93]">{format.time(bill.createdAt)}</p>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="text-sm text-[#1D1D1F]">{bill.items.length}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <p className="text-sm font-semibold text-[#007AFF]">{format.currency(bill.total)}</p>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={cn(
                        "inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium",
                        statusConfig[bill.status].color
                      )}>
                        {statusConfig[bill.status].label}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setSelectedBill(bill)}
                          className="p-1.5 text-[#007AFF] hover:bg-[#007AFF]/8 rounded-lg transition-colors"
                          title="ดูรายละเอียด"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handlePrint(bill)}
                          className="p-1.5 text-[#8E8E93] hover:bg-[#8E8E93]/8 rounded-lg transition-colors"
                          title="พิมพ์"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        {bill.status !== 'cancelled' && (
                          <button
                            onClick={() => updateBillStatus(bill.id, 'cancelled')}
                            className="p-1.5 text-[#FF3B30] hover:bg-[#FF3B30]/8 rounded-lg transition-colors"
                            title="ยกเลิก"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => deleteBill(bill.id)}
                          className="p-1.5 text-[#FF3B30] hover:bg-[#FF3B30]/8 rounded-lg transition-colors"
                          title="ลบ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-4 py-3 border-t border-[#E5E5E7] flex items-center justify-between">
            <p className="text-xs text-[#8E8E93]">
              แสดง {(currentPage - 1) * ITEMS_PER_PAGE + 1} - {Math.min(currentPage * ITEMS_PER_PAGE, filteredBills.length)} จาก {filteredBills.length} รายการ
            </p>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded-lg hover:bg-[#F5F5F7] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-2 text-sm font-medium text-[#1D1D1F]">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded-lg hover:bg-[#F5F5F7] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Bill Detail Dialog */}
      <Dialog open={!!selectedBill} onOpenChange={() => setSelectedBill(null)}>
        <DialogContent className="max-w-md p-0 gap-0 overflow-hidden">
          <DialogHeader className="p-4 border-b border-[#E5E5E7]">
            <DialogTitle className="flex items-center gap-2 text-base">
              <FileText className="w-5 h-5 text-[#007AFF]" />
              รายละเอียดบิล
            </DialogTitle>
          </DialogHeader>
          {selectedBill && (
            <div className="p-4 space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs text-[#8E8E93]">เลขที่บิล</p>
                  <p className="text-sm font-medium text-[#1D1D1F]">{selectedBill.billNumber}</p>
                </div>
                <span className={cn(
                  "inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium",
                  statusConfig[selectedBill.status].color
                )}>
                  {statusConfig[selectedBill.status].label}
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-[#8E8E93]">ลูกค้า</p>
                  <p className="text-sm text-[#1D1D1F]">{selectedBill.customerName || 'ลูกค้าทั่วไป'}</p>
                </div>
                <div>
                  <p className="text-xs text-[#8E8E93]">เบอร์โทร</p>
                  <p className="text-sm text-[#1D1D1F]">{selectedBill.customerPhone || '-'}</p>
                </div>
              </div>
              
              <div>
                <p className="text-xs text-[#8E8E93]">วันที่</p>
                <p className="text-sm text-[#1D1D1F]">{format.dateTime(selectedBill.createdAt)}</p>
              </div>
              
              <div className="border-t border-[#E5E5E7] pt-3">
                <p className="text-xs font-medium text-[#1D1D1F] mb-2">รายการยา</p>
                <div className="space-y-1.5">
                  {selectedBill.items.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span className="text-[#1D1D1F]">
                        {item.medicineName} <span className="text-[#8E8E93]">x{item.quantity}</span>
                      </span>
                      <span className="text-[#8E8E93]">{format.currency(item.total)}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="border-t border-[#E5E5E7] pt-3 space-y-1.5">
                <div className="flex justify-between text-sm">
                  <span className="text-[#8E8E93]">ยอดรวม</span>
                  <span className="text-[#1D1D1F]">{format.currency(selectedBill.subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-[#8E8E93]">ภาษี (7%)</span>
                  <span className="text-[#1D1D1F]">{format.currency(selectedBill.tax)}</span>
                </div>
                <div className="flex justify-between pt-2">
                  <span className="text-sm font-medium text-[#1D1D1F]">ยอดสุทธิ</span>
                  <span className="text-lg font-semibold text-[#007AFF]">{format.currency(selectedBill.total)}</span>
                </div>
              </div>
              
              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => handlePrint(selectedBill)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-[#007AFF] text-white rounded-xl hover:bg-[#0066CC] transition-colors text-sm font-medium"
                >
                  <Printer className="w-4 h-4" />
                  พิมพ์บิล
                </button>
                <button
                  onClick={() => setSelectedBill(null)}
                  className="px-4 py-2.5 bg-[#F5F5F7] text-[#1D1D1F] rounded-xl hover:bg-[#E5E5E7] transition-colors text-sm font-medium"
                >
                  ปิด
                </button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
