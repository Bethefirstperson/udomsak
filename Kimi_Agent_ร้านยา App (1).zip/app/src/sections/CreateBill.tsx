import { useState, useRef, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Minus, 
  Trash2, 
  User, 
  Phone, 
  Receipt,
  X,
  Check,
  ShoppingCart
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { Medicine } from '@/types';
import { format } from '@/lib/utils';
import { cn } from '@/lib/utils';

export function CreateBill() {
  const { 
    cart, 
    addToCart, 
    removeFromCart, 
    updateCartQuantity, 
    createBill,
    clearCart,
    searchMedicines,
    customers,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false);
  const [isCompleting, setIsCompleting] = useState(false);
  
  const searchRef = useRef<HTMLDivElement>(null);
  const customerRef = useRef<HTMLDivElement>(null);

  const suggestions = searchQuery ? searchMedicines(searchQuery) : [];
  const customerSuggestions = customerPhone ? customers.filter(c => c.phone.includes(customerPhone)) : [];

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.07;
  const total = subtotal + tax;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
      if (customerRef.current && !customerRef.current.contains(event.target as Node)) {
        setShowCustomerSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleAddMedicine = (medicine: Medicine) => {
    addToCart(medicine);
    setSearchQuery('');
    setShowSuggestions(false);
  };

  const handleSelectCustomer = (customer: typeof customers[0]) => {
    setCustomerName(customer.name);
    setCustomerPhone(customer.phone);
    setShowCustomerSuggestions(false);
  };

  const handleComplete = () => {
    if (cart.length === 0) return;
    setIsCompleting(true);
    createBill(customerName, customerPhone);
    setCustomerName('');
    setCustomerPhone('');
    setIsCompleting(false);
  };

  const handleClear = () => {
    clearCart();
    setCustomerName('');
    setCustomerPhone('');
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1D1D1F] tracking-tight">สร้างบิลใหม่</h1>
          <p className="text-sm text-[#8E8E93] mt-0.5">สร้างบิลขายยาสำหรับลูกค้า</p>
        </div>
        <button
          onClick={handleClear}
          className="flex items-center gap-2 px-3 py-2 text-[#FF3B30] hover:bg-[#FF3B30]/8 rounded-xl transition-colors text-sm font-medium"
        >
          <X className="w-4 h-4" />
          ล้างข้อมูล
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        {/* Left Column - Medicine Search & Cart */}
        <div className="lg:col-span-3 space-y-5">
          {/* Search */}
          <div className="bg-white rounded-2xl shadow-apple p-4" ref={searchRef}>
            <label className="block text-xs font-medium text-[#8E8E93] uppercase tracking-wide mb-2">
              ค้นหายา
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E8E93]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowSuggestions(e.target.value.length > 0);
                }}
                placeholder="พิมพ์ชื่อยาหรือหมวดหมู่..."
                className="w-full pl-9 pr-4 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#8E8E93] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
              />
              
              {/* Suggestions Dropdown */}
              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-apple-lg border border-[#E5E5E7] z-50 max-h-60 overflow-auto">
                  {suggestions.map((medicine) => (
                    <button
                      key={medicine.id}
                      onClick={() => handleAddMedicine(medicine)}
                      className="w-full px-4 py-3 flex items-center justify-between hover:bg-[#F5F5F7] transition-colors text-left"
                    >
                      <div>
                        <p className="text-sm font-medium text-[#1D1D1F]">{medicine.name}</p>
                        <p className="text-xs text-[#8E8E93]">{medicine.category}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-[#007AFF]">{format.currency(medicine.price)}</p>
                        <p className={cn(
                          "text-[10px]",
                          medicine.stock <= 10 ? "text-[#FF3B30]" : "text-[#8E8E93]"
                        )}>
                          คงเหลือ {medicine.stock}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Cart */}
          <div className="bg-white rounded-2xl shadow-apple overflow-hidden">
            <div className="p-4 border-b border-[#E5E5E7] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-[#007AFF]" strokeWidth={2} />
                <h3 className="font-semibold text-[#1D1D1F]">รายการยา</h3>
              </div>
              <span className="text-xs text-[#8E8E93] bg-[#F5F5F7] px-2 py-0.5 rounded-full">
                {cart.length} รายการ
              </span>
            </div>

            {cart.length === 0 ? (
              <div className="p-10 text-center">
                <div className="w-14 h-14 rounded-2xl bg-[#F5F5F7] flex items-center justify-center mx-auto mb-3">
                  <ShoppingCart className="w-6 h-6 text-[#C7C7CC]" />
                </div>
                <p className="text-sm text-[#8E8E93]">ยังไม่มีรายการยา</p>
                <p className="text-xs text-[#C7C7CC] mt-0.5">ค้นหาและเพิ่มยาเข้ารายการ</p>
              </div>
            ) : (
              <div className="divide-y divide-[#E5E5E7]">
                {cart.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 flex items-center gap-4"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-[#1D1D1F] truncate">{item.name}</p>
                      <p className="text-xs text-[#8E8E93]">{item.category}</p>
                    </div>
                    
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                        className="w-7 h-7 rounded-lg bg-[#F5F5F7] flex items-center justify-center hover:bg-[#E5E5E7] transition-colors"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                        className="w-7 h-7 rounded-lg bg-[#F5F5F7] flex items-center justify-center hover:bg-[#E5E5E7] transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    
                    <div className="text-right min-w-[80px]">
                      <p className="text-sm font-medium text-[#1D1D1F]">
                        {format.currency(item.price * item.quantity)}
                      </p>
                    </div>
                    
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-2 text-[#FF3B30] hover:bg-[#FF3B30]/8 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column - Customer Info & Checkout */}
        <div className="lg:col-span-2 space-y-5">
          {/* Customer Info */}
          <div className="bg-white rounded-2xl shadow-apple p-4 space-y-4">
            <h3 className="font-semibold text-[#1D1D1F] flex items-center gap-2 text-sm">
              <User className="w-4 h-4 text-[#007AFF]" />
              ข้อมูลลูกค้า
            </h3>
            
            <div className="space-y-3">
              <div ref={customerRef}>
                <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                  เบอร์โทรศัพท์
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E8E93]" />
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => {
                      setCustomerPhone(e.target.value);
                      setShowCustomerSuggestions(e.target.value.length > 0);
                    }}
                    placeholder="081-234-5678"
                    className="w-full pl-9 pr-4 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#8E8E93] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                  />
                  
                  {/* Customer Suggestions */}
                  {showCustomerSuggestions && customerSuggestions.length > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-apple-lg border border-[#E5E5E7] z-50">
                      {customerSuggestions.map((customer) => (
                        <button
                          key={customer.id}
                          onClick={() => handleSelectCustomer(customer)}
                          className="w-full px-4 py-3 flex items-center justify-between hover:bg-[#F5F5F7] transition-colors text-left"
                        >
                          <div>
                            <p className="text-sm font-medium text-[#1D1D1F]">{customer.name}</p>
                            <p className="text-xs text-[#8E8E93]">{customer.phone}</p>
                          </div>
                          <Check className="w-4 h-4 text-[#007AFF]" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                  ชื่อลูกค้า
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E8E93]" />
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="ชื่อ-นามสกุล"
                    className="w-full pl-9 pr-4 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#8E8E93] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Checkout Summary */}
          <div className="bg-white rounded-2xl shadow-apple p-4 space-y-4">
            <h3 className="font-semibold text-[#1D1D1F] flex items-center gap-2 text-sm">
              <Receipt className="w-4 h-4 text-[#007AFF]" />
              สรุปรายการ
            </h3>
            
            <div className="space-y-2 py-3 border-t border-b border-[#E5E5E7]">
              <div className="flex justify-between text-sm">
                <span className="text-[#8E8E93]">ยอดรวม</span>
                <span className="font-medium text-[#1D1D1F]">{format.currency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#8E8E93]">ภาษี (7%)</span>
                <span className="font-medium text-[#1D1D1F]">{format.currency(tax)}</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-[#1D1D1F]">ยอดสุทธิ</span>
              <span className="text-2xl font-semibold text-[#007AFF] tracking-tight">
                {format.currency(total)}
              </span>
            </div>
            
            <button
              onClick={handleComplete}
              disabled={cart.length === 0 || isCompleting}
              className={cn(
                "w-full py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-all",
                cart.length === 0
                  ? "bg-[#E5E5E7] text-[#C7C7CC] cursor-not-allowed"
                  : "bg-[#007AFF] text-white hover:bg-[#0066CC] shadow-apple hover:shadow-apple-hover"
              )}
            >
              <Check className="w-4 h-4" strokeWidth={2.5} />
              {isCompleting ? 'กำลังดำเนินการ...' : 'ยืนยันการขาย'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
