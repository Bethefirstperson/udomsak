import { useState } from 'react';
import { 
  Search, 
  Plus, 
  Users, 
  Edit2, 
  Trash2, 
  ChevronLeft,
  ChevronRight,
  Phone,
  ShoppingBag,
  Calendar,
  User
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { Customer } from '@/types';
import { format } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const ITEMS_PER_PAGE = 10;

export function Customers() {
  const { addCustomer, updateCustomer, deleteCustomer, searchCustomers } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewingCustomer, setViewingCustomer] = useState<Customer | null>(null);

  // Form states
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
  });

  const filteredCustomers = searchCustomers(searchQuery);

  const totalPages = Math.ceil(filteredCustomers.length / ITEMS_PER_PAGE);
  const paginatedCustomers = filteredCustomers.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingCustomer) {
      updateCustomer({ ...editingCustomer, name: formData.name, phone: formData.phone });
      setEditingCustomer(null);
    } else {
      addCustomer({ name: formData.name, phone: formData.phone });
    }

    setFormData({ name: '', phone: '' });
    setIsAddModalOpen(false);
  };

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setFormData({ name: customer.name, phone: customer.phone });
    setIsAddModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsAddModalOpen(false);
    setEditingCustomer(null);
    setFormData({ name: '', phone: '' });
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-[#1D1D1F] tracking-tight">ลูกค้า</h1>
          <p className="text-sm text-[#8E8E93] mt-0.5">จัดการข้อมูลลูกค้าและประวัติการซื้อ</p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#007AFF] text-white rounded-xl font-medium hover:bg-[#0066CC] transition-colors shadow-apple hover:shadow-apple-hover"
        >
          <Plus className="w-4 h-4" strokeWidth={2.5} />
          เพิ่มลูกค้า
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E8E93]" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setCurrentPage(1);
          }}
          placeholder="ค้นหาลูกค้าด้วยชื่อหรือเบอร์โทร..."
          className="w-full pl-9 pr-4 py-2.5 bg-white border-0 rounded-xl shadow-apple text-sm text-[#1D1D1F] placeholder:text-[#8E8E93] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
        />
      </div>

      {/* Customers Table */}
      <div className="bg-white rounded-2xl shadow-apple overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#F5F5F7]">
              <tr>
                <th className="px-4 py-3 text-left text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  ลูกค้า
                </th>
                <th className="px-4 py-3 text-left text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  เบอร์โทร
                </th>
                <th className="px-4 py-3 text-center text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  จำนวนครั้ง
                </th>
                <th className="px-4 py-3 text-right text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  ยอดซื้อรวม
                </th>
                <th className="px-4 py-3 text-left text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  ซื้อล่าสุด
                </th>
                <th className="px-4 py-3 text-center text-[10px] font-semibold text-[#8E8E93] uppercase tracking-wider">
                  จัดการ
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E5E7]">
              {paginatedCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center">
                    <Users className="w-10 h-10 mx-auto mb-2 text-[#E5E5E7]" />
                    <p className="text-sm text-[#8E8E93]">ไม่พบข้อมูลลูกค้า</p>
                  </td>
                </tr>
              ) : (
                paginatedCustomers.map((customer) => (
                  <tr key={customer.id} className="hover:bg-[#F5F5F7] transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#007AFF] to-[#5856D6] flex items-center justify-center flex-shrink-0">
                          <span className="text-xs font-semibold text-white">{customer.name.charAt(0)}</span>
                        </div>
                        <span className="text-sm font-medium text-[#1D1D1F]">{customer.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-[#8E8E93]" />
                        <span className="text-sm text-[#1D1D1F]">{customer.phone}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <ShoppingBag className="w-3.5 h-3.5 text-[#8E8E93]" />
                        <span className="text-sm text-[#1D1D1F]">{customer.totalVisits}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="text-sm font-semibold text-[#007AFF]">
                        {format.currency(customer.totalSpent)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {customer.lastVisit ? (
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-[#8E8E93]" />
                          <span className="text-sm text-[#1D1D1F]">
                            {format.date(customer.lastVisit)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-sm text-[#C7C7CC]">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setViewingCustomer(customer)}
                          className="p-1.5 text-[#007AFF] hover:bg-[#007AFF]/8 rounded-lg transition-colors"
                          title="ดูรายละเอียด"
                        >
                          <User className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEdit(customer)}
                          className="p-1.5 text-[#8E8E93] hover:bg-[#8E8E93]/8 rounded-lg transition-colors"
                          title="แก้ไข"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteCustomer(customer.id)}
                          className="p-1.5 text-[#FF3B30] hover:bg-[#FF3B30]/8 rounded-lg transition-colors"
                          title="ลบ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-4 py-3 border-t border-[#E5E5E7] flex items-center justify-between">
            <p className="text-xs text-[#8E8E93]">
              แสดง {(currentPage - 1) * ITEMS_PER_PAGE + 1} - {Math.min(currentPage * ITEMS_PER_PAGE, filteredCustomers.length)} จาก {filteredCustomers.length} รายการ
            </p>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded-lg hover:bg-[#F5F5F7] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-2 text-sm font-medium text-[#1D1D1F]">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded-lg hover:bg-[#F5F5F7] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={handleCloseModal}>
        <DialogContent className="max-w-md p-0 gap-0 overflow-hidden">
          <DialogHeader className="p-4 border-b border-[#E5E5E7]">
            <DialogTitle className="flex items-center gap-2 text-base">
              <User className="w-5 h-5 text-[#007AFF]" />
              {editingCustomer ? 'แก้ไขข้อมูลลูกค้า' : 'เพิ่มลูกค้าใหม่'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="p-4 space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                ชื่อลูกค้า
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                placeholder="ชื่อ-นามสกุล"
              />
            </div>
            
            <div>
              <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                เบอร์โทรศัพท์
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
                className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                placeholder="081-234-5678"
              />
            </div>
            
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={handleCloseModal}
                className="flex-1 px-4 py-2.5 bg-[#F5F5F7] text-[#1D1D1F] rounded-xl hover:bg-[#E5E5E7] transition-colors text-sm font-medium"
              >
                ยกเลิก
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2.5 bg-[#007AFF] text-white rounded-xl hover:bg-[#0066CC] transition-colors text-sm font-medium"
              >
                {editingCustomer ? 'บันทึกการแก้ไข' : 'เพิ่มลูกค้า'}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* View Customer Detail Modal */}
      <Dialog open={!!viewingCustomer} onOpenChange={() => setViewingCustomer(null)}>
        <DialogContent className="max-w-md p-0 gap-0 overflow-hidden">
          <DialogHeader className="p-4 border-b border-[#E5E5E7]">
            <DialogTitle className="flex items-center gap-2 text-base">
              <User className="w-5 h-5 text-[#007AFF]" />
              ข้อมูลลูกค้า
            </DialogTitle>
          </DialogHeader>
          {viewingCustomer && (
            <div className="p-4 space-y-5">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#007AFF] to-[#5856D6] flex items-center justify-center">
                  <span className="text-lg font-semibold text-white">{viewingCustomer.name.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-[#1D1D1F]">{viewingCustomer.name}</h3>
                  <div className="flex items-center gap-1.5 text-[#8E8E93]">
                    <Phone className="w-3.5 h-3.5" />
                    <span className="text-sm">{viewingCustomer.phone}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#F5F5F7] rounded-xl p-3 text-center">
                  <ShoppingBag className="w-5 h-5 mx-auto mb-1.5 text-[#007AFF]" />
                  <p className="text-xl font-semibold text-[#1D1D1F]">{viewingCustomer.totalVisits}</p>
                  <p className="text-xs text-[#8E8E93]">จำนวนครั้งที่ซื้อ</p>
                </div>
                <div className="bg-[#F5F5F7] rounded-xl p-3 text-center">
                  <div className="w-5 h-5 mx-auto mb-1.5 rounded-full bg-[#007AFF]/10 flex items-center justify-center">
                    <span className="text-[#007AFF] font-bold text-xs">฿</span>
                  </div>
                  <p className="text-xl font-semibold text-[#007AFF]">
                    {format.currency(viewingCustomer.totalSpent)}
                  </p>
                  <p className="text-xs text-[#8E8E93]">ยอดซื้อรวม</p>
                </div>
              </div>

              <div>
                <p className="text-xs text-[#8E8E93] mb-1">ซื้อล่าสุด</p>
                <p className="text-sm text-[#1D1D1F]">
                  {viewingCustomer.lastVisit 
                    ? format.dateTime(viewingCustomer.lastVisit)
                    : 'ยังไม่มีประวัติการซื้อ'
                  }
                </p>
              </div>

              <button
                onClick={() => setViewingCustomer(null)}
                className="w-full px-4 py-2.5 bg-[#F5F5F7] text-[#1D1D1F] rounded-xl hover:bg-[#E5E5E7] transition-colors text-sm font-medium"
              >
                ปิด
              </button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
