import { 
  DollarSign, 
  Receipt, 
  Pill, 
  AlertTriangle,
  TrendingUp,
  Calendar,
  ChevronRight
} from 'lucide-react';
import { StatCard } from '@/components/StatCard';
import { useApp } from '@/context/AppContext';
import { format } from '@/lib/utils';
import { cn } from '@/lib/utils';

export function Dashboard() {
  const { stats, bills, medicines, setCurrentView } = useApp();

  const recentBills = bills.slice(0, 5);
  const lowStockMedicines = medicines.filter(m => m.stock <= 10).slice(0, 5);

  const today = new Date();
  const thaiDate = format.dateThai(today);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1D1D1F] tracking-tight">แดชบอร์ด</h1>
          <p className="text-sm text-[#8E8E93] mt-0.5 flex items-center gap-1.5">
            <Calendar className="w-4 h-4" />
            {thaiDate}
          </p>
        </div>
        <button
          onClick={() => setCurrentView('create-bill')}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#007AFF] text-white rounded-xl font-medium hover:bg-[#0066CC] transition-colors shadow-apple hover:shadow-apple-hover"
        >
          <Receipt className="w-4 h-4" strokeWidth={2.5} />
          สร้างบิลใหม่
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="ยอดขายวันนี้"
          value={format.currency(stats.totalSalesToday)}
          icon={DollarSign}
          color="blue"
          change={12.5}
          changeLabel="จากเมื่อวาน"
        />
        <StatCard
          title="จำนวนบิลวันนี้"
          value={stats.totalBillsToday}
          icon={Receipt}
          color="green"
          change={8.2}
          changeLabel="จากเมื่อวาน"
        />
        <StatCard
          title="จำนวนยาทั้งหมด"
          value={stats.totalMedicines}
          icon={Pill}
          color="purple"
        />
        <StatCard
          title="สินค้าใกล้หมด"
          value={stats.lowStockItems}
          icon={AlertTriangle}
          color="red"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Bills */}
        <div className="bg-white rounded-2xl shadow-apple overflow-hidden">
          <div className="p-4 border-b border-[#E5E5E7] flex items-center justify-between">
            <h3 className="font-semibold text-[#1D1D1F]">บิลล่าสุด</h3>
            <button
              onClick={() => setCurrentView('bills')}
              className="text-sm text-[#007AFF] hover:text-[#0066CC] font-medium flex items-center gap-0.5"
            >
              ดูทั้งหมด
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="divide-y divide-[#E5E5E7]">
            {recentBills.length === 0 ? (
              <div className="p-8 text-center text-[#8E8E93]">
                <Receipt className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p className="text-sm">ยังไม่มีบิล</p>
              </div>
            ) : (
              recentBills.map((bill, index) => (
                <div
                  key={bill.id}
                  className="p-4 hover:bg-[#F5F5F7] transition-colors"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-[#1D1D1F]">{bill.billNumber}</p>
                      <p className="text-xs text-[#8E8E93] mt-0.5">{bill.customerName}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-[#007AFF]">{format.currency(bill.total)}</p>
                      <span className={cn(
                        "inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium mt-1",
                        bill.status === 'paid' && "bg-[#34C759]/10 text-[#34C759]",
                        bill.status === 'pending' && "bg-[#FF9500]/10 text-[#FF9500]",
                        bill.status === 'cancelled' && "bg-[#FF3B30]/10 text-[#FF3B30]"
                      )}>
                        {bill.status === 'paid' && 'ชำระแล้ว'}
                        {bill.status === 'pending' && 'รอชำระ'}
                        {bill.status === 'cancelled' && 'ยกเลิก'}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-white rounded-2xl shadow-apple overflow-hidden">
          <div className="p-4 border-b border-[#E5E5E7] flex items-center justify-between">
            <h3 className="font-semibold text-[#1D1D1F]">แจ้งเตือนสต็อกต่ำ</h3>
            <button
              onClick={() => setCurrentView('medicines')}
              className="text-sm text-[#007AFF] hover:text-[#0066CC] font-medium flex items-center gap-0.5"
            >
              ดูทั้งหมด
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="divide-y divide-[#E5E5E7]">
            {lowStockMedicines.length === 0 ? (
              <div className="p-8 text-center text-[#8E8E93]">
                <Pill className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p className="text-sm">ไม่มีสินค้าใกล้หมด</p>
              </div>
            ) : (
              lowStockMedicines.map((medicine, index) => (
                <div
                  key={medicine.id}
                  className="p-4 hover:bg-[#F5F5F7] transition-colors"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-[#1D1D1F]">{medicine.name}</p>
                      <p className="text-xs text-[#8E8E93] mt-0.5">{medicine.category}</p>
                    </div>
                    <div className="text-right">
                      <p className={cn(
                        "text-sm font-semibold",
                        medicine.stock <= 5 ? "text-[#FF3B30]" : "text-[#FF9500]"
                      )}>
                        เหลือ {medicine.stock} ชิ้น
                      </p>
                      <span className="text-xs text-[#8E8E93]">{format.currency(medicine.price)}/ชิ้น</span>
                    </div>
                  </div>
                  <div className="mt-2.5 h-1 bg-[#E5E5E7] rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-500",
                        medicine.stock <= 5 ? "bg-[#FF3B30]" : "bg-[#FF9500]"
                      )}
                      style={{ width: `${Math.min((medicine.stock / 20) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-2xl shadow-apple p-4">
        <h3 className="font-semibold text-[#1D1D1F] mb-3 text-sm">ทำงานด่วน</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'สร้างบิล', icon: Receipt, view: 'create-bill' as const, color: '#007AFF' },
            { label: 'เพิ่มยา', icon: Pill, view: 'medicines' as const, color: '#34C759' },
            { label: 'เพิ่มลูกค้า', icon: TrendingUp, view: 'customers' as const, color: '#5856D6' },
            { label: 'ดูรายงาน', icon: TrendingUp, view: 'reports' as const, color: '#FF9500' },
          ].map((action) => (
            <button
              key={action.label}
              onClick={() => setCurrentView(action.view)}
              className="flex items-center gap-3 p-3 rounded-xl bg-[#F5F5F7] hover:bg-[#E5E5E7] transition-colors group"
            >
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 transition-transform duration-200 group-hover:scale-105"
                style={{ backgroundColor: `${action.color}15` }}
              >
                <action.icon className="w-4 h-4" style={{ color: action.color }} strokeWidth={2} />
              </div>
              <span className="text-sm font-medium text-[#1D1D1F]">{action.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
