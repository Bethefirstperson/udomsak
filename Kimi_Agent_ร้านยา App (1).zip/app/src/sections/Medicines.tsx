import { useState } from 'react';
import { 
  Search, 
  Plus, 
  Pill, 
  Edit2, 
  Trash2, 
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { Medicine } from '@/types';
import { format } from '@/lib/utils';
import { cn } from '@/lib/utils';
import { categories } from '@/data/mockData';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const ITEMS_PER_PAGE = 12;

export function Medicines() {
  const { medicines, addMedicine, updateMedicine, deleteMedicine, searchMedicines } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);

  // Form states
  const [formData, setFormData] = useState({
    name: '',
    category: categories[1],
    description: '',
    price: '',
    stock: '',
  });

  const filteredMedicines = medicines.filter(medicine => {
    const matchesSearch = searchMedicines(searchQuery).includes(medicine);
    const matchesCategory = selectedCategory === 'All' || medicine.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const totalPages = Math.ceil(filteredMedicines.length / ITEMS_PER_PAGE);
  const paginatedMedicines = filteredMedicines.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const medicineData = {
      name: formData.name,
      category: formData.category,
      description: formData.description,
      price: parseFloat(formData.price),
      stock: parseInt(formData.stock),
    };

    if (editingMedicine) {
      updateMedicine({ ...editingMedicine, ...medicineData });
      setEditingMedicine(null);
    } else {
      addMedicine(medicineData);
    }

    setFormData({ name: '', category: categories[1], description: '', price: '', stock: '' });
    setIsAddModalOpen(false);
  };

  const handleEdit = (medicine: Medicine) => {
    setEditingMedicine(medicine);
    setFormData({
      name: medicine.name,
      category: medicine.category,
      description: medicine.description,
      price: medicine.price.toString(),
      stock: medicine.stock.toString(),
    });
    setIsAddModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsAddModalOpen(false);
    setEditingMedicine(null);
    setFormData({ name: '', category: categories[1], description: '', price: '', stock: '' });
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-[#1D1D1F] tracking-tight">คลังยา</h1>
          <p className="text-sm text-[#8E8E93] mt-0.5">จัดการรายการยาและสต็อกสินค้า</p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#007AFF] text-white rounded-xl font-medium hover:bg-[#0066CC] transition-colors shadow-apple hover:shadow-apple-hover"
        >
          <Plus className="w-4 h-4" strokeWidth={2.5} />
          เพิ่มยาใหม่
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E8E93]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="ค้นหายา..."
            className="w-full pl-9 pr-4 py-2.5 bg-white border-0 rounded-xl shadow-apple text-sm text-[#1D1D1F] placeholder:text-[#8E8E93] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
          />
        </div>
        <select
          value={selectedCategory}
          onChange={(e) => {
            setSelectedCategory(e.target.value);
            setCurrentPage(1);
          }}
          className="px-3 py-2.5 bg-white border-0 rounded-xl shadow-apple text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
        >
          {categories.map(cat => (
            <option key={cat} value={cat}>
              {cat === 'All' ? 'ทุกหมวดหมู่' : cat}
            </option>
          ))}
        </select>
      </div>

      {/* Medicines Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {paginatedMedicines.length === 0 ? (
          <div className="col-span-full py-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-[#F5F5F7] flex items-center justify-center mx-auto mb-3">
              <Pill className="w-7 h-7 text-[#C7C7CC]" />
            </div>
            <p className="text-sm text-[#8E8E93]">ไม่พบรายการยา</p>
          </div>
        ) : (
          paginatedMedicines.map((medicine) => (
            <div
              key={medicine.id}
              className="bg-white rounded-2xl shadow-apple overflow-hidden hover:shadow-apple-hover transition-all duration-300 group"
            >
              {/* Card Header */}
              <div className="p-4 bg-gradient-to-br from-[#007AFF]/5 to-[#5856D6]/5 flex items-center justify-center h-20">
                <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center shadow-apple">
                  <Pill className="w-5 h-5 text-[#007AFF]" strokeWidth={2} />
                </div>
              </div>

              {/* Card Content */}
              <div className="p-4">
                <h3 className="font-medium text-[#1D1D1F] line-clamp-1 mb-1" title={medicine.name}>
                  {medicine.name}
                </h3>
                
                <span className="inline-block px-2 py-0.5 bg-[#F5F5F7] text-[#8E8E93] text-[10px] rounded-md mb-2">
                  {medicine.category}
                </span>
                
                <p className="text-xs text-[#8E8E93] line-clamp-2 mb-3 h-8">
                  {medicine.description}
                </p>

                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="text-[10px] text-[#8E8E93]">ราคา</p>
                    <p className="text-sm font-semibold text-[#007AFF]">{format.currency(medicine.price)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-[#8E8E93]">คงเหลือ</p>
                    <p className={cn(
                      "text-sm font-semibold",
                      medicine.stock <= 5 ? "text-[#FF3B30]" : 
                      medicine.stock <= 10 ? "text-[#FF9500]" : "text-[#34C759]"
                    )}>
                      {medicine.stock}
                    </p>
                  </div>
                </div>

                {/* Stock Indicator */}
                <div className="mb-3">
                  <div className="h-1 bg-[#E5E5E7] rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-500",
                        medicine.stock <= 5 ? "bg-[#FF3B30]" : 
                        medicine.stock <= 10 ? "bg-[#FF9500]" : "bg-[#34C759]"
                      )}
                      style={{ width: `${Math.min((medicine.stock / 50) * 100, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(medicine)}
                    className="flex-1 flex items-center justify-center gap-1 px-3 py-2 bg-[#F5F5F7] text-[#007AFF] rounded-lg hover:bg-[#007AFF]/10 transition-colors text-xs font-medium"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    แก้ไข
                  </button>
                  <button
                    onClick={() => deleteMedicine(medicine.id)}
                    className="flex items-center justify-center px-3 py-2 bg-[#F5F5F7] text-[#FF3B30] rounded-lg hover:bg-[#FF3B30]/10 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between bg-white rounded-2xl shadow-apple p-3">
          <p className="text-xs text-[#8E8E93]">
            แสดง {(currentPage - 1) * ITEMS_PER_PAGE + 1} - {Math.min(currentPage * ITEMS_PER_PAGE, filteredMedicines.length)} จาก {filteredMedicines.length} รายการ
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg hover:bg-[#F5F5F7] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 text-sm font-medium text-[#1D1D1F]">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg hover:bg-[#F5F5F7] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={handleCloseModal}>
        <DialogContent className="max-w-md p-0 gap-0 overflow-hidden">
          <DialogHeader className="p-4 border-b border-[#E5E5E7]">
            <DialogTitle className="flex items-center gap-2 text-base">
              <Pill className="w-5 h-5 text-[#007AFF]" />
              {editingMedicine ? 'แก้ไขข้อมูลยา' : 'เพิ่มยาใหม่'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="p-4 space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                ชื่อยา
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                placeholder="เช่น Paracetamol 500mg"
              />
            </div>
            
            <div>
              <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                หมวดหมู่
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
              >
                {categories.filter(c => c !== 'All').map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                รายละเอียด
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all resize-none"
                placeholder="รายละเอียดการใช้งาน..."
              />
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                  ราคา (บาท)
                </label>
                <input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  required
                  min="0"
                  step="0.01"
                  className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                  จำนวนในสต็อก
                </label>
                <input
                  type="number"
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                  required
                  min="0"
                  className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                  placeholder="0"
                />
              </div>
            </div>
            
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={handleCloseModal}
                className="flex-1 px-4 py-2.5 bg-[#F5F5F7] text-[#1D1D1F] rounded-xl hover:bg-[#E5E5E7] transition-colors text-sm font-medium"
              >
                ยกเลิก
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2.5 bg-[#007AFF] text-white rounded-xl hover:bg-[#0066CC] transition-colors text-sm font-medium"
              >
                {editingMedicine ? 'บันทึกการแก้ไข' : 'เพิ่มยา'}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
