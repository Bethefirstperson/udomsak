import { useState, useMemo } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign,
  Receipt,
  Download
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { format } from '@/lib/utils';
import { cn } from '@/lib/utils';

export function Reports() {
  const { bills, medicines, customers } = useApp();
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'year'>('today');

  const stats = useMemo(() => {
    const now = new Date();
    let startDate: Date;

    switch (dateRange) {
      case 'today':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
    }

    const filteredBills = bills.filter(b => {
      const billDate = new Date(b.createdAt);
      return billDate >= startDate && b.status === 'paid';
    });

    const totalSales = filteredBills.reduce((sum, b) => sum + b.total, 0);
    const totalBills = filteredBills.length;
    const averageBill = totalBills > 0 ? totalSales / totalBills : 0;

    // Top selling medicines
    const medicineSales: Record<string, { name: string; quantity: number; revenue: number }> = {};
    filteredBills.forEach(bill => {
      bill.items.forEach(item => {
        if (!medicineSales[item.medicineId]) {
          medicineSales[item.medicineId] = {
            name: item.medicineName,
            quantity: 0,
            revenue: 0,
          };
        }
        medicineSales[item.medicineId].quantity += item.quantity;
        medicineSales[item.medicineId].revenue += item.total;
      });
    });

    const topMedicines = Object.values(medicineSales)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);

    // Top customers
    const customerStats: Record<string, { name: string; visits: number; spent: number }> = {};
    filteredBills.forEach(bill => {
      if (bill.customerPhone) {
        if (!customerStats[bill.customerPhone]) {
          customerStats[bill.customerPhone] = {
            name: bill.customerName,
            visits: 0,
            spent: 0,
          };
        }
        customerStats[bill.customerPhone].visits += 1;
        customerStats[bill.customerPhone].spent += bill.total;
      }
    });

    const topCustomers = Object.values(customerStats)
      .sort((a, b) => b.spent - a.spent)
      .slice(0, 5);

    return {
      totalSales,
      totalBills,
      averageBill,
      topMedicines,
      topCustomers,
    };
  }, [bills, dateRange]);

  const handleExport = () => {
    const data = {
      dateRange,
      generatedAt: new Date().toISOString(),
      stats,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `report-${dateRange}-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const dateRangeLabels = {
    today: 'วันนี้',
    week: '7 วันล่าสุด',
    month: 'เดือนนี้',
    year: 'ปีนี้',
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-[#1D1D1F] tracking-tight">รายงาน</h1>
          <p className="text-sm text-[#8E8E93] mt-0.5">สรุปยอดขายและสถิติต่างๆ</p>
        </div>
        <button
          onClick={handleExport}
          className="flex items-center gap-2 px-3 py-2 bg-white rounded-xl shadow-apple hover:shadow-apple-hover transition-all text-sm font-medium text-[#1D1D1F]"
        >
          <Download className="w-4 h-4" />
          ส่งออกรายงาน
        </button>
      </div>

      {/* Date Range Filter */}
      <div className="flex flex-wrap gap-1.5 bg-white p-1 rounded-xl shadow-apple w-fit">
        {(['today', 'week', 'month', 'year'] as const).map((range) => (
          <button
            key={range}
            onClick={() => setDateRange(range)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
              dateRange === range
                ? "bg-[#007AFF] text-white"
                : "text-[#8E8E93] hover:text-[#1D1D1F] hover:bg-[#F5F5F7]"
            )}
          >
            {dateRangeLabels[range]}
          </button>
        ))}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl shadow-apple p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-[#8E8E93] uppercase tracking-wide mb-1">ยอดขายรวม</p>
              <h3 className="text-2xl font-semibold text-[#007AFF] tracking-tight">
                {format.currency(stats.totalSales)}
              </h3>
            </div>
            <div className="w-11 h-11 rounded-xl bg-[#007AFF]/8 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-[#007AFF]" strokeWidth={2} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-apple p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-[#8E8E93] uppercase tracking-wide mb-1">จำนวนบิล</p>
              <h3 className="text-2xl font-semibold text-[#34C759] tracking-tight">
                {format.number(stats.totalBills)}
              </h3>
            </div>
            <div className="w-11 h-11 rounded-xl bg-[#34C759]/8 flex items-center justify-center">
              <Receipt className="w-5 h-5 text-[#34C759]" strokeWidth={2} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-apple p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-[#8E8E93] uppercase tracking-wide mb-1">ยอดเฉลี่ยต่อบิล</p>
              <h3 className="text-2xl font-semibold text-[#AF52DE] tracking-tight">
                {format.currency(stats.averageBill)}
              </h3>
            </div>
            <div className="w-11 h-11 rounded-xl bg-[#AF52DE]/8 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-[#AF52DE]" strokeWidth={2} />
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top Selling Medicines */}
        <div className="bg-white rounded-2xl shadow-apple p-5">
          <h3 className="font-semibold text-[#1D1D1F] mb-4 flex items-center gap-2 text-sm">
            <TrendingUp className="w-4 h-4 text-[#34C759]" />
            ยาขายดี
          </h3>
          {stats.topMedicines.length === 0 ? (
            <div className="py-8 text-center text-[#8E8E93]">
              <p className="text-sm">ไม่มีข้อมูล</p>
            </div>
          ) : (
            <div className="space-y-3">
              {stats.topMedicines.map((medicine, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-md bg-[#F5F5F7] flex items-center justify-center text-xs font-semibold text-[#8E8E93]">
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[#1D1D1F] truncate">{medicine.name}</p>
                    <p className="text-xs text-[#8E8E93]">{medicine.quantity} ชิ้น</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-[#007AFF]">{format.currency(medicine.revenue)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Top Customers */}
        <div className="bg-white rounded-2xl shadow-apple p-5">
          <h3 className="font-semibold text-[#1D1D1F] mb-4 flex items-center gap-2 text-sm">
            <TrendingUp className="w-4 h-4 text-[#007AFF]" />
            ลูกค้าซื้อเยอะ
          </h3>
          {stats.topCustomers.length === 0 ? (
            <div className="py-8 text-center text-[#8E8E93]">
              <p className="text-sm">ไม่มีข้อมูล</p>
            </div>
          ) : (
            <div className="space-y-3">
              {stats.topCustomers.map((customer, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-md bg-[#F5F5F7] flex items-center justify-center text-xs font-semibold text-[#8E8E93]">
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[#1D1D1F] truncate">{customer.name}</p>
                    <p className="text-xs text-[#8E8E93]">{customer.visits} ครั้ง</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-[#007AFF]">{format.currency(customer.spent)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Inventory Summary */}
      <div className="bg-white rounded-2xl shadow-apple p-5">
        <h3 className="font-semibold text-[#1D1D1F] mb-4 flex items-center gap-2 text-sm">
          <BarChart3 className="w-4 h-4 text-[#AF52DE]" />
          สรุปคลังสินค้า
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-[#F5F5F7] rounded-xl p-4">
            <p className="text-xs text-[#8E8E93] mb-1">จำนวนยาทั้งหมด</p>
            <p className="text-xl font-semibold text-[#1D1D1F]">{medicines.length}</p>
          </div>
          <div className="bg-[#34C759]/8 rounded-xl p-4">
            <p className="text-xs text-[#34C759] mb-1">สต็อกปกติ</p>
            <p className="text-xl font-semibold text-[#34C759]">
              {medicines.filter(m => m.stock > 10).length}
            </p>
          </div>
          <div className="bg-[#FF9500]/8 rounded-xl p-4">
            <p className="text-xs text-[#FF9500] mb-1">ใกล้หมด</p>
            <p className="text-xl font-semibold text-[#FF9500]">
              {medicines.filter(m => m.stock > 0 && m.stock <= 10).length}
            </p>
          </div>
          <div className="bg-[#FF3B30]/8 rounded-xl p-4">
            <p className="text-xs text-[#FF3B30] mb-1">หมดสต็อก</p>
            <p className="text-xl font-semibold text-[#FF3B30]">
              {medicines.filter(m => m.stock === 0).length}
            </p>
          </div>
        </div>
      </div>

      {/* Customer Summary */}
      <div className="bg-white rounded-2xl shadow-apple p-5">
        <h3 className="font-semibold text-[#1D1D1F] mb-4 flex items-center gap-2 text-sm">
          <BarChart3 className="w-4 h-4 text-[#FF9500]" />
          สรุปลูกค้า
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-[#F5F5F7] rounded-xl p-4">
            <p className="text-xs text-[#8E8E93] mb-1">จำนวนลูกค้าทั้งหมด</p>
            <p className="text-xl font-semibold text-[#1D1D1F]">{customers.length}</p>
          </div>
          <div className="bg-[#007AFF]/8 rounded-xl p-4">
            <p className="text-xs text-[#007AFF] mb-1">ลูกค้าใหม่ (เดือนนี้)</p>
            <p className="text-xl font-semibold text-[#007AFF]">
              {customers.filter(c => {
                if (!c.lastVisit) return false;
                const lastVisit = new Date(c.lastVisit);
                const now = new Date();
                return lastVisit.getMonth() === now.getMonth() && lastVisit.getFullYear() === now.getFullYear();
              }).length}
            </p>
          </div>
          <div className="bg-[#34C759]/8 rounded-xl p-4">
            <p className="text-xs text-[#34C759] mb-1">ลูกค้าประจำ (ซื้อ 5+ ครั้ง)</p>
            <p className="text-xl font-semibold text-[#34C759]">
              {customers.filter(c => c.totalVisits >= 5).length}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
