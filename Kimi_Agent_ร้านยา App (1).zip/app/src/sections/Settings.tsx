import { useState } from 'react';
import { 
  Store,
  User,
  Bell,
  Shield,
  Save,
  Check
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function Settings() {
  const [activeTab, setActiveTab] = useState<'store' | 'account' | 'notifications' | 'security'>('store');
  const [saved, setSaved] = useState(false);

  // Store settings
  const [storeSettings, setStoreSettings] = useState({
    name: 'PharmaFlow Pharmacy',
    address: '123 ถนนสุขุมวิท แขวงคลองเตย เขตคลองเตย กรุงเทพฯ 10110',
    phone: '02-123-4567',
    email: 'contact@pharmaflow.com',
    taxId: '1234567890123',
  });

  // Account settings
  const [accountSettings, setAccountSettings] = useState({
    name: 'เภสัชกร',
    email: 'pharmacist@pharmaflow.com',
    phone: '081-234-5678',
  });

  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    lowStockAlert: true,
    dailyReport: true,
    newCustomerAlert: false,
    billCompleteSound: true,
  });

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const tabs = [
    { id: 'store' as const, label: 'ข้อมูลร้าน', icon: Store },
    { id: 'account' as const, label: 'บัญชีผู้ใช้', icon: User },
    { id: 'notifications' as const, label: 'การแจ้งเตือน', icon: Bell },
    { id: 'security' as const, label: 'ความปลอดภัย', icon: Shield },
  ];

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-[#1D1D1F] tracking-tight">ตั้งค่า</h1>
        <p className="text-sm text-[#8E8E93] mt-0.5">จัดการการตั้งค่าระบบ</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Sidebar Tabs */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl shadow-apple overflow-hidden">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 text-left transition-colors",
                    activeTab === tab.id
                      ? "bg-[#007AFF]/10 text-[#007AFF]"
                      : "text-[#8E8E93] hover:text-[#1D1D1F] hover:bg-[#F5F5F7]"
                  )}
                >
                  <Icon className="w-4 h-4" strokeWidth={2} />
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-2xl shadow-apple p-5">
            {/* Store Settings */}
            {activeTab === 'store' && (
              <div className="space-y-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-9 h-9 rounded-xl bg-[#007AFF]/10 flex items-center justify-center">
                    <Store className="w-4 h-4 text-[#007AFF]" strokeWidth={2} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#1D1D1F]">ข้อมูลร้าน</h3>
                    <p className="text-xs text-[#8E8E93]">ตั้งค่าข้อมูลพื้นฐานของร้าน</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                      ชื่อร้าน
                    </label>
                    <input
                      type="text"
                      value={storeSettings.name}
                      onChange={(e) => setStoreSettings({ ...storeSettings, name: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                      เบอร์โทรศัพท์
                    </label>
                    <input
                      type="tel"
                      value={storeSettings.phone}
                      onChange={(e) => setStoreSettings({ ...storeSettings, phone: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                      ที่อยู่
                    </label>
                    <textarea
                      value={storeSettings.address}
                      onChange={(e) => setStoreSettings({ ...storeSettings, address: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all resize-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                      อีเมล
                    </label>
                    <input
                      type="email"
                      value={storeSettings.email}
                      onChange={(e) => setStoreSettings({ ...storeSettings, email: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                      เลขประจำตัวผู้เสียภาษี
                    </label>
                    <input
                      type="text"
                      value={storeSettings.taxId}
                      onChange={(e) => setStoreSettings({ ...storeSettings, taxId: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Account Settings */}
            {activeTab === 'account' && (
              <div className="space-y-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-9 h-9 rounded-xl bg-[#34C759]/10 flex items-center justify-center">
                    <User className="w-4 h-4 text-[#34C759]" strokeWidth={2} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#1D1D1F]">บัญชีผู้ใช้</h3>
                    <p className="text-xs text-[#8E8E93]">จัดการข้อมูลส่วนตัว</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#007AFF] to-[#5856D6] flex items-center justify-center">
                    <span className="text-lg font-semibold text-white">PH</span>
                  </div>
                  <div>
                    <button className="px-3 py-2 bg-[#F5F5F7] text-[#1D1D1F] rounded-xl hover:bg-[#E5E5E7] transition-colors text-xs font-medium">
                      เปลี่ยนรูปโปรไฟล์
                    </button>
                    <p className="text-[10px] text-[#8E8E93] mt-1.5">รองรับไฟล์ JPG, PNG ขนาดไม่เกิน 2MB</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                      ชื่อผู้ใช้
                    </label>
                    <input
                      type="text"
                      value={accountSettings.name}
                      onChange={(e) => setAccountSettings({ ...accountSettings, name: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                      อีเมล
                    </label>
                    <input
                      type="email"
                      value={accountSettings.email}
                      onChange={(e) => setAccountSettings({ ...accountSettings, email: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                      เบอร์โทรศัพท์
                    </label>
                    <input
                      type="tel"
                      value={accountSettings.phone}
                      onChange={(e) => setAccountSettings({ ...accountSettings, phone: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#F5F5F7] border-0 rounded-xl text-sm text-[#1D1D1F] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Notification Settings */}
            {activeTab === 'notifications' && (
              <div className="space-y-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-9 h-9 rounded-xl bg-[#FF9500]/10 flex items-center justify-center">
                    <Bell className="w-4 h-4 text-[#FF9500]" strokeWidth={2} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#1D1D1F]">การแจ้งเตือน</h3>
                    <p className="text-xs text-[#8E8E93]">ตั้งค่าการแจ้งเตือนต่างๆ</p>
                  </div>
                </div>

                <div className="space-y-2">
                  {[
                    { key: 'lowStockAlert', label: 'แจ้งเตือนสินค้าใกล้หมด', desc: 'แจ้งเตือนเมื่อสินค้าในสต็อกเหลือน้อยกว่า 10 ชิ้น' },
                    { key: 'dailyReport', label: 'รายงานประจำวัน', desc: 'ส่งรายงานยอดขายประจำวันทุกวันเวลา 20:00' },
                    { key: 'newCustomerAlert', label: 'แจ้งเตือนลูกค้าใหม่', desc: 'แจ้งเตือนเมื่อมีลูกค้าใหม่ลงทะเบียน' },
                    { key: 'billCompleteSound', label: 'เสียงแจ้งเตือนเมื่อขายสำเร็จ', desc: 'เล่นเสียงเมื่อสร้างบิลสำเร็จ' },
                  ].map((item) => (
                    <div key={item.key} className="flex items-center justify-between p-3 bg-[#F5F5F7] rounded-xl">
                      <div>
                        <p className="text-sm font-medium text-[#1D1D1F]">{item.label}</p>
                        <p className="text-xs text-[#8E8E93]">{item.desc}</p>
                      </div>
                      <button
                        onClick={() => setNotificationSettings(prev => ({
                          ...prev,
                          [item.key]: !prev[item.key as keyof typeof notificationSettings]
                        }))}
                        className={cn(
                          "w-11 h-6 rounded-full transition-colors relative",
                          notificationSettings[item.key as keyof typeof notificationSettings]
                            ? "bg-[#34C759]"
                            : "bg-[#E5E5E7]"
                        )}
                      >
                        <div className={cn(
                          "w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all shadow-sm",
                          notificationSettings[item.key as keyof typeof notificationSettings]
                            ? "left-5.5"
                            : "left-0.5"
                        )} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Security Settings */}
            {activeTab === 'security' && (
              <div className="space-y-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-9 h-9 rounded-xl bg-[#FF3B30]/10 flex items-center justify-center">
                    <Shield className="w-4 h-4 text-[#FF3B30]" strokeWidth={2} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#1D1D1F]">ความปลอดภัย</h3>
                    <p className="text-xs text-[#8E8E93]">จัดการความปลอดภัยของบัญชี</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="p-4 bg-[#F5F5F7] rounded-xl">
                    <h4 className="font-medium text-[#1D1D1F] mb-3 text-sm">เปลี่ยนรหัสผ่าน</h4>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                          รหัสผ่านปัจจุบัน
                        </label>
                        <input
                          type="password"
                          placeholder="••••••••"
                          className="w-full px-3 py-2.5 bg-white border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                          รหัสผ่านใหม่
                        </label>
                        <input
                          type="password"
                          placeholder="••••••••"
                          className="w-full px-3 py-2.5 bg-white border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-[#8E8E93] mb-1.5">
                          ยืนยันรหัสผ่านใหม่
                        </label>
                        <input
                          type="password"
                          placeholder="••••••••"
                          className="w-full px-3 py-2.5 bg-white border-0 rounded-xl text-sm text-[#1D1D1F] placeholder:text-[#C7C7CC] focus:outline-none focus:ring-2 focus:ring-[#007AFF]/20 transition-all"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-[#F5F5F7] rounded-xl">
                    <h4 className="font-medium text-[#1D1D1F] mb-1 text-sm">การยืนยันตัวตนแบบสองขั้นตอน (2FA)</h4>
                    <p className="text-xs text-[#8E8E93] mb-3">
                      เพิ่มความปลอดภัยด้วยการยืนยันตัวตนผ่านแอพ Authenticator
                    </p>
                    <button className="px-3 py-2 bg-white text-[#1D1D1F] rounded-xl hover:bg-[#E5E5E7] transition-colors text-xs font-medium">
                      เปิดใช้งาน 2FA
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Save Button */}
            <div className="mt-6 pt-5 border-t border-[#E5E5E7] flex justify-end">
              <button
                onClick={handleSave}
                className={cn(
                  "flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium transition-all text-sm",
                  saved
                    ? "bg-[#34C759] text-white"
                    : "bg-[#007AFF] text-white hover:bg-[#0066CC]"
                )}
              >
                {saved ? (
                  <>
                    <Check className="w-4 h-4" />
                    บันทึกสำเร็จ
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    บันทึกการตั้งค่า
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
