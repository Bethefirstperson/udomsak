export interface BillItem {
  medicineId: string;
  medicineName: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Bill {
  id: string;
  billNumber: string;
  customerName: string;
  customerPhone: string;
  items: BillItem[];
  subtotal: number;
  tax: number;
  total: number;
  status: 'paid' | 'pending' | 'cancelled';
  createdAt: string;
}

export interface Medicine {
  id: string;
  name: string;
  category: string;
  description: string;
  price: number;
  stock: number;
  image?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  totalVisits: number;
  totalSpent: number;
  lastVisit: string;
}

export interface CartItem extends Medicine {
  quantity: number;
}

export type ViewType = 'dashboard' | 'create-bill' | 'bills' | 'medicines' | 'customers' | 'reports' | 'settings';

export interface Stats {
  totalSalesToday: number;
  totalBillsToday: number;
  totalMedicines: number;
  lowStockItems: number;
}
